#pragma once

struct CartItem {
	size_t productId;
	size_t categoryId; 
	double quantity;
	double pricePerItem;
};